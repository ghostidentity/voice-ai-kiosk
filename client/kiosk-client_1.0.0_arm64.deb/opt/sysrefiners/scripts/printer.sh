#!/bin/bash

# Configuration
RFCOMM_PORT=0
RFCOMM_DEVICE="/dev/rfcomm$RFCOMM_PORT"
SPP_CHANNEL=1
SPP_UUID="00001101-0000-1000-8000-00805f9b34fb" 

# Variables to store the found printer's info
PRINTER_MAC=""
PRINTER_NAME=""

# --- 1. FIND PRINTER ---
# Informational start
echo "Checking for printer..."

devices_list=$(bluetoothctl devices)
while IFS= read -r line; do
    if [[ "$line" =~ ^Device ]]; then
        mac=$(echo "$line" | awk '{print $2}')
        name=$(echo "$line" | awk '{$1=$2=""; print $0}' | xargs)
        uuid_check=$(bluetoothctl info "$mac" | grep -F "$SPP_UUID")

        if [ -n "$uuid_check" ]; then
            PRINTER_MAC="$mac"
            PRINTER_NAME="$name"
            # Printer found, stop searching
            break 
        fi
    fi
done <<< "$devices_list"

if [ -z "$PRINTER_MAC" ]; then
    # Error State 1: No printer found
    echo -e "❌ \e[31mFailed:\e[0m No SPP-capable printer found."
    exit 1
fi

# --- 2. CHECK BINDING STATUS ---
is_bound=$(rfcomm -a 2>/dev/null | grep -F "$PRINTER_MAC")

if [ -n "$is_bound" ]; then
    # Final State A: Already Bound
    echo -e "✅ \e[32mReady:\e[0m \e[1m$PRINTER_NAME\e[0m bound to \e[1m$RFCOMM_DEVICE\e[0m."
    exit 0
fi

# --- 3. ATTEMPT TO BIND (Requires Sudo) ---
BIND_COMMAND="rfcomm bind $RFCOMM_PORT $PRINTER_MAC $SPP_CHANNEL"
eval $BIND_COMMAND

if [ $? -eq 0 ]; then
    # Final State B: Bind Successful
    echo -e "✅ \e[32mReady:\e[0m \e[1m$PRINTER_NAME\e[0m bound to \e[1m$RFCOMM_DEVICE\e[0m."
else
    # Final State C: Bind Failed
    echo -e "❌ \e[31mFailed:\e[0m Could not bind \e[1m$PRINTER_NAME\e[0m to $RFCOMM_DEVICE."
    echo -e "   \e[31mHINT:\e[0m Requires \e[1msudo\e[0m privileges."
    exit 1
fi